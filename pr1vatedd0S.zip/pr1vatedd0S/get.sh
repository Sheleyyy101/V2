#!/bin/bash

echo "Removing old proxys"
rm -rf proxynofilter.txt proxyfilter.txt proxy.txt 2>/dev/null
echo "Downloading proxy."
wget "https://www.proxy-list.download/api/v1/get?type=http" -O proxynofilter.txt 2>/dev/null
wget "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all&simplified=true" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt 2>/dev/null
rm -rf proxy.txt
wget "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt
rm -rf proxy.txt
wget "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt
rm -rf proxy.txt
wget "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt
rm -rf proxy.txt
wget "https://raw.githubusercontent.com/Volodichev/proxy-list/main/http.txt" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt
rm -rf proxy.txt
cat proxynofilter.txt | sort | uniq > proxy.txt 2>/dev/null
mv proxy.txt proxynofilter.txt 2>/dev/null
echo "Done"

node proxychecker.js proxynofilter.txt http proxyfilter.txt 100
