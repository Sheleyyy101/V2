module.exports = {
    ddosguard:require('./cloudflare'),
    blazingfast: require('./blazingfast'),
    browser_engine: require('./browser_engine'),
    ovh: require('./ovh'),
    pipeguard: require('./pipeguard'),
    privacypass: require('./privacypass'),
    sucuri: require('./sucuri'),
    cloudflare: require('./cloudflare'),
    stormwall: require('./stormwall')
}