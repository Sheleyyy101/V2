apt -y update; apt -y install screen
apt install python
apt install python2
apt install golang
apt install nodejs
pip3 install -r requirements.txt
python3 c2-fix.py