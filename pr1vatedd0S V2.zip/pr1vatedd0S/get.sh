#!/bin/bash

echo -e "\033[1;32mRemoving old proxy...\033[0m"

echo -e "\033[1;32mDone, \033[1;33mremoved proxynofilter.txt proxyfilter.txt\033[0m"

rm -rf proxynofilter.txt proxyfilter.txt 2>/dev/null

echo -e "\033[1;32mDownloading proxy...\033[0m"

wget "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all&simplified=true" -O proxynofilter.txt 2>/dev/null

wget "https://www.proxy-list.download/api/v1/get?type=http" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt 2>/dev/null
rm -rf proxy.txt 2>/dev/null

wget "https://www.proxyscan.io/download?type=http" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt 2>/dev/null
rm -rf proxy.txt 2>/dev/null

wget "https://sheesh.rip/http.txt" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt 2>/dev/null
rm -rf proxy.txt 2>/dev/null

wget "https://openproxylist.xyz/http.txt" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt 2>/dev/null
rm -rf proxy.txt 2>/dev/null

wget "https://proxyspace.pro/http.txt" -O proxy.txt 2>/dev/null
cat proxy.txt >> proxynofilter.txt 2>/dev/null
rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/UserR3X/proxy-list/main/online/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/RX4096/proxy-list/main/online/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

#wget "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt" -O proxy.txt 2>/dev/null
#cat proxy.txt >> proxynofilter.txt 2>/dev/null
#rm -rf proxy.txt 2>/dev/null

cat proxynofilter.txt | sort | uniq > proxy.txt 2>/dev/null
mv proxy.txt proxynofilter.txt 2>/dev/null

echo -e "\033[1;32mDone, \033[1;33msave as proxynofilter.txt\033[0m"

echo -e "\033[1;36mCheck proxy life, please wait. Cancel try Ctrl + C.\033[0m"

echo -e "\033[1;32mAfter done, \033[1;33save as proxyfilter.txt\033[0m"


node proxychecker.js proxynofilter.txt http proxyfilter.txt 100
